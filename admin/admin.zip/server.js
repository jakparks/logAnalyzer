// Variables
var express = require('express'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override'),
    morgan = require('morgan'),
    http = require('http'),
    path = require('path'),
    fs = require('fs'),
    propsReader = require('properties-reader'),
    port = 3000,
    server = express(),
    passport = require('passport'),
    LocalStrategy = require('passport-local').Strategy,
    DEFAULT_PORT = 3000,
    DEFAULT_THEME = "superhero",
    DEFAULT_AVATAR = "http://www.lezebre.lu/images/21913-scooby-doo-mystery-machine-fleur.png",
    mongo = require('mongodb'),
    bb = require("bluebird"),
    log4js = require("log4js");

// Configure Logging including mogran for all HTTP requests
log4js.configure({
   appenders: [
       { type: 'file', filename: '/apps/var/log/nodejs/admin.log', category: 'mystery', 'maxLogSize': 1000000, 'backups': 10 }
   ]
});
log4js.replaceConsole();
var logger = log4js.getLogger('mystery');
var theHTTPLog = morgan({
  "format": "tiny",
  "stream": {
    write: function(str) { logger.info(str); }
  }
});
server.use(theHTTPLog);

// Server setup
server.use(bodyParser.json());
server.use("/bower_components", express.static(__dirname + "/client/bower_components")); // Treat all bower_components requests as static content
server.use("/mystery*", function(req, res, next) { // Send these request to the main index.html to be routed by Angular
    res.sendFile(__dirname + "/index.html");
});
server.use("/client", express.static(__dirname + "/client")); // Treat all client requests as static content
server.use(function(req, res, next) {
    req.db = db;
    next();
});

var basicAuth = require('basic-auth-connect');
server.use(basicAuth('admin', 'mmcisco123'));

// Mongodb promises
bb.promisifyAll(mongo);
bb.promisifyAll(mongo.Db.prototype);
bb.promisifyAll(mongo.Collection.prototype);

// Setup database connections
var dbProps = propsReader('/apps/etc/mongodb.properties');
var db = null;
var dbAdmin = null;
var dbWait = bb.defer();
var dbAdminWait = bb.defer()
logger.info("Connecting to MM database");
connectToDb(dbWait, "mongodb://" + dbProps.get("username") + ":" + dbProps.get("password") + "@" + dbProps.get("server") + "/" + dbProps.get("dbName")).then(function(conn) {
	db = conn;
	logger.info("Connecting to Admin database");
	return connectToDb(dbAdminWait, "mongodb://admin:" + dbProps.get("password") + "@" + dbProps.get("server") + "/admin").then(function(conn) {
		dbAdmin = conn;
	});
}).catch(function(e){
	logger.error("Error connecting to the database. " + e);
}).finally(function() {
	server.listen(port, function() {
  	logger.info('Mystery Machine server listening on port ' + port);
	});
});

// Global values
// Page size
var PAGE_SIZE = 15;


// ********************************** common routines start here ***********************************************

function connectToDb(wait, database) {
   logger.info("connectToDb: database=" + database);
   mongo.connectAsync(database).then(function(conn) {
	  logger.info("Connected and authenticated.");
	  wait.resolve(conn);
   }).catch(function(e){
	logger.error("Error connecting to the database. " + e);
        setTimeout(function () {
	   connectToDb(wait, database);
        }, 5000);
   });
   return wait.promise;
}

function writeResponse(res, status, result) {
   var response = {
       "status": status,
       "result": result
   };
   logger.info("Response to client: " + JSON.stringify(response));
   res.writeHead(200, {
       'Content-Type': 'application/json'
   });
   res.write(JSON.stringify(response));
   res.end();
}

function writeResponse(res, status, result, cnt, startIndex, numRecords) {
   var response = {
       "status": status,
       "result": result,
       "totalRecords" : cnt,
       "startIndex" : startIndex,
       "pageSize" : PAGE_SIZE,
       "numRecords" : numRecords
   };
   logger.info("Response to client: " + JSON.stringify(response));
   res.writeHead(200, {
       'Content-Type': 'application/json'
   });
   res.write(JSON.stringify(response));
   res.end();
}


// ********************************** routes start here ***********************************************


// Route to fetch scoreboard stats
server.get('/api/scoreboard/stats', function(req, res) {
    logger.info("Fetching scoreboard stats...");
    var scoreboard = {
        stats: {
          "totalUsersNoDevices": 0,
          "totalUserProfiles": 0,
          "totalDatasets": 0,
          "totalVisits": 0,
          "totalPushNotifDevices": 0,
          "totalActivePushNotifDevices": 0,
          "totalInactivePushNotifDevices": 0,
          "totalSubscriptions": 0
        }
    };

    // Count all subscriptions
    db.collection("subscription").count(function(err, cnt) {
        scoreboard.stats.totalSubscriptions = cnt;
    });
    // Count all user profiles
    db.collection("userProfile").count(function(err, cnt) {
        scoreboard.stats.totalUserProfiles = cnt;
    });

   // Total Push Device Count
   // var userProfileCollection = db.collection("userProfile");
   // userProfileCollection.aggregate( [
       // { $project: {pushNotifDevices: 1 }},
       // { $unwind: "$pushNotifDevices" },
       // { $group: {_id: "result", count: { $sum: 1 }}}
       // ], function(err, result) {
          // scoreboard.stats.totalPushNotifDevices = result[0].count;
   // });

     //Get number of active devices
     userProfileCollection = db.collection("userProfile");
     userProfileCollection.aggregate( [
        { $project: { pushNotifDevices: 1 }},
        { $match: { "pushNotifDevices.active": true }},
        { $unwind: "$pushNotifDevices"},
        { $group: { _id: "result", count: { $sum: 1 }}}
        ], function(err, result) {
            scoreboard.stats.totalActivePushNotifDevices = result[0].count;
    });

     //Get number of inactive devices
     userProfileCollection = db.collection("userProfile");
     userProfileCollection.aggregate( [
        { $project: { pushNotifDevices: 1 }},
        { $match: { "pushNotifDevices.active": false }},
        { $unwind: "$pushNotifDevices"},
        { $group: {_id: "result", count: { $sum: 1 }}}
        ], function(err, result) {
            scoreboard.stats.totalInactivePushNotifDevices = result[0].count;
    });

    db.collection("userNoDevices").count(function(err, cnt) {
        scoreboard.stats.totalUsersNoDevices = cnt;
        db.collection("datasets").count(function(err, cnt) {
            scoreboard.stats.totalDatasets = cnt;
            var response = {
                "status": "success",
                "result": scoreboard.stats
            };
            res.writeHead(200, {
                'Content-Type': 'application/json'
            });
            res.write(JSON.stringify(response));
            res.end();
        });
    });
});

// Route to fetch userNoDevices
server.get('/api/userNoDevices', function(req, res) {
    logger.info("Fetching userNoDevices");
    var startIndex  = parseInt(req.query.startIndex),
        skip = startIndex > 0 ? startIndex-1 : 0;
    logger.info("startIndex " + startIndex + " size=" + PAGE_SIZE + " skip=" + skip);
    db.collection("userNoDevices").countAsync().then(function (cnt) {
       db.collection('userNoDevices').find(null, null, { skip: skip, limit: PAGE_SIZE }).sort({
        modDate: -1
    }).toArray(function(err, result) {
        if (err) {
	   logger.error("Error. " + err);
	   writeResponse(res, "failure", "");
	} else {
           logger.info(result);
	   writeResponse(res, "success", result, cnt, skip+1, result.length);
	}
    })
    });
});

// Route to fetch pushHistory
server.get('/api/pushHistory', function(req, res) {
    logger.info("Fetching pushHistory");
    var skip = 0,
        numberOfDays = parseInt(req.query.numberOfDays),
        startDate = new Date();
    startDate.setDate(startDate.getDate() - numberOfDays);
    var startDateStr = startDate.getFullYear() + '-' + ('0' + (startDate.getMonth()+1)).slice(-2) + '-' + ('0' + startDate.getDate()).slice(-2);
    db.collection("metrics").countAsync({day: {"$gte": startDateStr}, area: 'pushNotifier'}).then(function (cnt) {
       db.collection('metrics').find({day: {"$gte": startDateStr}, area: 'pushNotifier'}, null, {skip: skip}).sort({
        day: 1
    }).toArray(function(err, result) {
        if (err) {
           logger.error("Error. " + err);
           writeResponse(res, "failure", "");
        } else {
           logger.info("myResp = " + result);
           writeResponse(res, "success", result, cnt, skip+1, result.length);
        }
    })
    });
});

// Route to fetch metrics
server.get('/api/metrics', function(req, res) {
    logger.info("Fetching metrics");
    var area = req.query.area,
        startIndex  = parseInt(req.query.startIndex),
        skip = startIndex > 0 ? startIndex-1 : 0;
    logger.info("area=" + area + " startIndex " + startIndex + " size=" + PAGE_SIZE + " skip=" + skip);
    db.collection("metrics").countAsync({area: area}).then(function (cnt) {
       db.collection('metrics').find({area: area}, null, { skip: skip, limit: PAGE_SIZE }).sort({
        day: -1
    }).toArray(function(err, result) {
        if (err) {
	   logger.error("Error. " + err);
	   writeResponse(res, "failure", "");
	} else {
           logger.info(result);
	   writeResponse(res, "success", result, cnt, skip+1, result.length);
	}
    })
    });
});

// Route to fetch metricsMessageBus
server.get('/api/metricsMessageBus', function(req, res) {
    logger.info("Fetching metricsMessageBus");
    var startIndex  = parseInt(req.query.startIndex),
        skip = startIndex > 0 ? startIndex-1 : 0;
    logger.info("startIndex " + startIndex + " size=" + PAGE_SIZE + " skip=" + skip);
    db.collection("metricsMessageBus").countAsync().then(function (cnt) {
       db.collection('metricsMessageBus').find(null, null, { skip: skip, limit: PAGE_SIZE }).sort({
        day: -1, topic: 1, type: -1
    }).toArray(function(err, result) {
        if (err) {
	   logger.error("Error. " + err);
	   writeResponse(res, "failure", "");
	} else {
           logger.info(result);
	   writeResponse(res, "success", result, cnt, skip+1, result.length);
	}
    })
    });
});

// Route to fetch replication status
server.get('/api/replStatus', function(req, res) {
    logger.info("Fetching replication status");
    var adminDb = dbAdmin.admin();
    adminDb.replSetGetStatus(function(err, result) {
        if (err) {
	   logger.error("Error. " + err);
	   writeResponse(res, "failure", "");
	} else {
           logger.info(result);
	   writeResponse(res, "success", result);
	}
    });
});


function spawnTopicStatus(group, topic) {
    logger.info("spawnTopicStatus: group=" + group + " topic=" + topic);
    var retResult = [];
    var deferred = bb.defer();
    var spawn = require('child_process').spawn;
    var child = spawn("/apps/kafka/bin/kafka-run-class.sh", ["kafka.tools.ConsumerOffsetChecker", "--group", group, "--zkconnect", "localhost:2181", "--topic", topic]);
    var str = "";
    child.stdout.on('data', function(chunk) {
        logger.info("chunk=" + chunk);
        str += chunk;
    });
    child.on('exit', function(code) {
        var arr = str.split("\n");
        for (var i = 1; i < arr.length; i++) {
            var values = arr[i].split(/[ ]+/);
            if (values.length != 7) {
                continue;
            }
            var topicLine = {
                "group": values[0],
                "topic": values[1],
                "pid": values[2],
                "offSet": values[3],
                "logSize": values[4],
                "lag": values[5],
                "owner": values[6]
            };
            retResult.push(topicLine);
        }
        deferred.resolve(retResult);
    });

    return deferred.promise;
}

// Route to fetch topic status
server.get('/api/topicStatus', function(req, res) {
    logger.info("Fetching topic status");

    // Get the consumer groups and topics from the metrics table
    var deferred = bb.defer();
    db.collection('metricsMessageBus').aggregate([ {"$match":{"type": "consumer"}}, {$group : { _id : {"group":"$group","topic":"$topic" } }}
    ], function(err, result) {
        if (err) {
	   logger.error("Error. " + err);
	   writeResponse(res, "failure", "");
	   return;
	}
        logger.info(result);
        var retResult = [];
        var spawnCount = 0;
        var topicCount = result.length;
        for (var i = 0; i < result.length; i++) {
            var topic = result[i];
            spawnTopicStatus(topic["_id"].group, topic["_id"].topic).then(function(result) {
                retResult = retResult.concat(result);
                if (++spawnCount == topicCount) {
                    deferred.resolve();
                }
            })
        }

        deferred.promise.then(function(result) {
	   writeResponse(res, "success", retResult);
        })
    });
});
