var mysteryMachine = angular.module("mm", ["ngRoute", "ui.bootstrap"]);

var selectedTitle = "";

// This  maps URLS/Routes to pages and controllers
mysteryMachine.config(["$routeProvider", "$locationProvider", "$httpProvider",
    function($routeProvider, $locationProvider, $httpProvider) {
        $locationProvider.html5Mode(true);
        $routeProvider
            .when("/mystery", {
                templateUrl: "/client/templates/home.html",
                controller: "homeController"
            })
            .when("/mystery/metrics/:area", {
                templateUrl: "/client/templates/metrics.html",
                controller: "metricsController"
            })
            .when("/mystery/metricsMessageBus", {
                templateUrl: "/client/templates/metricsMessageBus.html",
                controller: "metricsMessageBusController"
            })
            .when("/mystery/userNoDevices", {
                templateUrl: "/client/templates/userNoDevices.html",
                controller: "userNoDevicesController"
            })
            .when("/mystery/status", {
                templateUrl: "/client/templates/status.html",
                controller: "statusController"
            })
            .otherwise({
                redirectTo: "/"
            });
    }
]);

// This is the main controller that drives the side menu
mysteryMachine.controller("rootController", function($scope, $http, $location) {
    $scope.isLogin = ($location.path() === '/mystery/login') ? true : false;
    if (!$scope.isLogin) {
        var navs = [{
            "name": "Dashboard",
            "url": "/mystery",
            "isActive": true
        }, {
            "name": "Metrics",
            "isActive": false,
	    "url": "",
	    "submenu" : [
		{
                   "name": "Case Adaptor",
                   "url": "/mystery/metrics/caseAdaptor",
                   "isActive": false
		},{
                   "name": "Rules Engine",
                   "url": "/mystery/metrics/rulesEngine",
                   "isActive": false
                },{
                   "name": "Bulk Notifier",
                   "url": "/mystery/metrics/bulkNotifier",
                   "isActive": false
                },{
                   "name": "User Profile Web Service",
                   "url": "/mystery/metrics/userProfileWS",
                   "isActive": false
                },{
                   "name": "Subscription Web Service",
                   "url": "/mystery/metrics/subscriptionWS",
                   "isActive": false
                },{
                   "name": "Notification Web Service",
                   "url": "/mystery/metrics/notificationWS",
                   "isActive": false
                },{
                   "name": "Push Notifier",
                   "url": "/mystery/metrics/pushNotifier",
                   "isActive": false
                },{
                   "name": "Apollo Notifier",
                   "url": "/mystery/metrics/apolloNotifier",
                   "isActive": false
		},{
                   "name": "Message Bus",
                   "url": "/mystery/metricsMessageBus",
                   "isActive": false
		}
	     ]
        }, {
            "name": "Users",
            "isActive": false,
	    "url": "",
	    "submenu" : [
		{
                   "name": "No Mobile Devices",
                   "url": "/mystery/userNoDevices",
                   "isActive": false
		}
	     ]
        }, {
            "name": "Status",
            "url": "/mystery/status",
            "isActive": false
        }];
        $scope.navs = navs;
    }

    $scope.onNavSwitch = function(nav) {
        _.each($scope.navs, function(nav) {
            nav.isActive = false;
            if (nav.submenu) {
               _.each(nav.submenu, function(subnav) {
                  subnav.isActive = false;
               });
            }
        });
        nav.isActive = true;
        selectedTitle = nav.name;
    };
});

// This is the home controller
mysteryMachine.controller("homeController", function($scope, $http) {


    $http.get("/api/scoreboard/stats")
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.stats = response.data.result;
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve stats from server. Reason: " + err);
        })
        .finally(function() {

        });

    var allHistory = new allNotifHistory();
    var seriesArray = [];
    $http.get("/api/pushHistory?numberOfDays=90")
        .then(function(response) {
            if (response && response.data && response.data.result) {
                var result = response.data.result;
                for (var i=0; i<response.data.result.length; i++) {
                    var keys = Object.keys(response.data.result[i]);
                    var size = keys.length;
                    for (var j = 0; j < size; j++) {
                        var key = keys[j];
                        if (key == '_id' || key == 'day' || key == 'area' || key.indexOf('New Psirt') == 0) {
                           continue;
                        }
                        allHistory.updateNotifHistory(key, result[i].day, result[i][key]);
                     }
                }
                for (var k=0; k<allHistory.history.length; k++) {
                    seriesArray.push({name: allHistory.history[k].name, data: allHistory.history[k].data});
                }
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve stats from server. Reason: " + err);
        })
        .finally(function() {
            // Build the chart
            $('#pushHistoryChart').highcharts({
                chart: {
                    type:'area',
                    backgroundColor: "transparent"
                },
                title: {
                    text: "Push Notifications (90 Days)",
                    style: {
                        color: "#ebebeb"
                    }
                },
                xAxis: {
                    type: 'datetime'
                },
                yAxis: {
                    title: {text: 'Notifications Sent'}
                },
                plotOptions: {
                    series: {
                        stacking: 'normal'
                    }
                },
                legend: {
                    itemStyle: {
                        color: "#ebebeb"
                    }
                },
                credits: {
                    enabled: false
                },
                series: seriesArray
            });
        });
});

// This is the userNoDevices controller 
mysteryMachine.controller("userNoDevicesController", ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams) {
    $scope.showSpinner = true;
    $http.get("/api/userNoDevices?startIndex=" + $routeParams.startIndex)
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.userNoDevices = response.data.result;
		$scope.startIndex = response.data.startIndex;
		$scope.pageSize = response.data.pageSize;
		$scope.numRecords = response.data.numRecords;
		$scope.totalRecords = response.data.totalRecords;
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve userNoDevices from server. Reason: " + err);
        })
        .finally(function() {
            $scope.showSpinner = false;
        });
}]);

// This is the metrics controller 
mysteryMachine.controller("metricsController", ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams) {
    $scope.showSpinner = true;
    $http.get("/api/metrics?area=" + $routeParams.area + "&startIndex=" + $routeParams.startIndex)
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.metrics = response.data.result;
		$scope.startIndex = response.data.startIndex;
		$scope.pageSize = response.data.pageSize;
		$scope.numRecords = response.data.numRecords;
		$scope.totalRecords = response.data.totalRecords;
		$scope.title = selectedTitle;
		// Determine the headers
                var headerArray = [];
                for (var i = 0; i < response.data.result.length; i++) {
                        var keys = Object.keys(response.data.result[i]);
                        var size = keys.length;
                        for (var j = 0; j < size; j++) {
                                if (headerArray.indexOf(keys[j]) > -1) {
                                        continue;
                                }
                                headerArray.push(keys[j]);
                        }
                }
                $scope.headers = headerArray.sort();
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve metrics from server. Reason: " + err);
        })
        .finally(function() {
            $scope.showSpinner = false;
        });
}]);

// This is the metricsMessageBus controller 
mysteryMachine.controller("metricsMessageBusController", ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams) {
    $scope.showSpinner = true;
    $http.get("/api/metricsMessageBus?startIndex=" + $routeParams.startIndex)
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.metrics = response.data.result;
		$scope.startIndex = response.data.startIndex;
		$scope.pageSize = response.data.pageSize;
		$scope.numRecords = response.data.numRecords;
		$scope.totalRecords = response.data.totalRecords;
		$scope.title = selectedTitle;
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve metrics from server. Reason: " + err);
        })
        .finally(function() {
            $scope.showSpinner = false;
        });
}]);

// This is the status controller
mysteryMachine.controller("statusController", function($scope, $http) {
    $scope.showReplStatusSpinner = true;
    $http.get("/api/replStatus")
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.replStatus = response.data.result;
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve replication status from server. Reason: " + err);
        })
        .finally(function() {
            $scope.showReplStatusSpinner = false;
        });

    $scope.showTopicStatusSpinner = true;
    $http.get("/api/topicStatus")
        .then(function(response) {
            if (response && response.data && response.data.result) {
                $scope.topicStatus = response.data.result;
            }
        })
        .catch(function(err) {
            console.error("Failed to retrieve kafka topic status from server. Reason: " + err);
        })
        .finally(function() {
            $scope.showTopicStatusSpinner = false;
        });
});

mysteryMachine.filter('timeAgo', function() {
    return function(date, unix) {
        return moment(date).fromNow();
    };
});

// Objects/methods for building push notif history
function notifTypeHistory(name) {
     this.name = name;
     this.data = [];
     this.addPoint = function (date, count) {
         this.data.push([Date.parse(date), count]);
     }
}

function allNotifHistory() {
    this.history = [];
    this.updateNotifHistory = function (type, date, count) {
        // Check if this type already has an entry
        var match = false;

        for (i=0; i<this.history.length; i++) {
            if (this.history[i].name.localeCompare(type) == 0) {
                this.history[i].addPoint(date, count);
                match = true;
                break;
            }
        }

        if (match == false) {
             // Create an entry for this type and store point
             var newType = new notifTypeHistory(type);
             newType.addPoint(date, count);
             this.history.push(newType);
        }
    }
}
